module.exports = {
  apps: [{ name: 'app', script: './build/index.js', instances: 2 }]
};
